module.exports ={
    EMAIL:'tejvarun7396@gmail.com',
    PASSWORD:'qmel yzuz jvnc ndto'
}